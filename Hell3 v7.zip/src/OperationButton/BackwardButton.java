package OperationButton;

import java.awt.Color;
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

import Operation.Backward;
import Operation.Operation;

public class BackwardButton extends OperationButton{

	public BackwardButton(String name) {
		super("");
		
		setBackground(new Color(0,0,0,0));
		try {
			Image img = ImageIO.read(new File("resources/moveBackward.png"));
			setIcon(new ImageIcon(img));
		} catch (IOException ex) {
		}
		
	}
	
	@Override
	public Operation GenerateNewOperateInstance() {
		// TODO Auto-generated method stub
		return new Backward();
	}
}
