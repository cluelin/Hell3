package OperationButton;

import java.awt.Color;
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

import Operation.Forward;
import Operation.Operation;

public class ForwardButton extends OperationButton{

	public ForwardButton(String name) {
		super("");
		
		setBackground(new Color(0,0,0,0));
		try {
			Image img = ImageIO.read(new File("resources/moveForward.png"));
			setIcon(new ImageIcon(img));
		} catch (IOException ex) {
		}
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public Operation GenerateNewOperateInstance() {
		
		return  new Forward();
	}

}
