package OperationButton;

import Operation.Operation;

import java.awt.Color;
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

import Operation.LeftRotate;

public class LeftRotateButton extends OperationButton {

	
	public LeftRotateButton(String name) {
		// TODO Auto-generated constructor stub
		super("");
		
		setBackground(new Color(0,0,0,0));
		try {
			Image img = ImageIO.read(new File("resources/rotateLeft.png"));
			setIcon(new ImageIcon(img));
		} catch (IOException ex) {
		}
	}
	
	@Override
	public Operation GenerateNewOperateInstance() {
		// TODO Auto-generated method stub
		return new LeftRotate();
	}
}
