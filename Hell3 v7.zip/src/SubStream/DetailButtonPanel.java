package SubStream;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JPanel;

public class DetailButtonPanel extends JPanel{

	public DetailButtonPanel(int width, int height){
		
		setLayout(new FlowLayout());
//		setBackground(new Color(255, 0, 0, 255));
		setBackground(Color.lightGray);
		setPreferredSize(new Dimension(width, height));
	}
	
	
}
