package SubStream;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

import GUIPackage.GUI;
import Operation.Backward;
import Operation.LeftRotate;
import Operation.RightRotate;
import OperationButton.BackwardButton;
import OperationButton.ForwardButton;
import OperationButton.LeftRotateButton;
import OperationButton.OperationButton;
import OperationButton.RightRotateButton;

public class MoveButtonPanel extends JPanel {

	OperationButton forwardButton = new ForwardButton("Forward");
	OperationButton backwardButton = new BackwardButton("Backward");
	OperationButton rightRotateButton = new RightRotateButton("Right Rotate");
	OperationButton leftRotateButton = new LeftRotateButton("Left Rotate");
	
	public MoveButtonPanel(int width, int height) {

		setLayout(new FlowLayout());
//		setBackground(new Color(0, 0, 20, 50));
		setBackground(Color.lightGray);
		setPreferredSize(new Dimension(width, height));

		makeMoveButton();
	}

	public void makeMoveButton() {
		

		forwardButton.setPreferredSize(new Dimension(150, 50));
		backwardButton.setPreferredSize(new Dimension(150, 50));
		rightRotateButton.setPreferredSize(new Dimension(150, 50));
		leftRotateButton.setPreferredSize(new Dimension(150, 50));

		forwardButton.addActionListener(new ButtonActionListener());
		backwardButton.addActionListener(new ButtonActionListener());
		rightRotateButton.addActionListener(new ButtonActionListener());
		leftRotateButton.addActionListener(new ButtonActionListener());

		add(forwardButton);
		add(backwardButton);
		add(rightRotateButton);
		add(leftRotateButton);

	}

	// Move��ư ���������� ��ư Ŭ�� ������.
	class ButtonActionListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {

			//operation��ư�� Ŭ���ɶ�,   �� ��ư ���� code �гο� �߰�. 
			OperationButton res = (OperationButton)e.getSource();
			try {
				
				Image selectedImage = ImageIO.read(new File("resources/Right_s.png"));
				res.setIcon(new ImageIcon(selectedImage));
				
			} catch (IOException ex) {
			}
			GUI.mainFrame.addOperationButtonInCodePanel(res.GenerateNewOperateInstance());
			
			

		}
	}

}
